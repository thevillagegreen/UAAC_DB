// Update with your config settings.

module.exports = {
  development : {
    client: 'mysql',
    connection: {
      host     : '35.184.227.103',
      user     : 'root',
      password : 'abc123',
      database : 'uaac'
    }
  }
};
